package com.example.guillermojos_escuderoamodeo_examen1.entidades;

import java.util.ArrayList;

public interface IDaoExamen {

    public void addExamen(examen e);
    public void deleteExamen(examen e);

}
