package com.example.guillermojos_escuderoamodeo_examen1.entidades;

import java.util.ArrayList;

public class ModeloDB {

    public static  examen examen=new examen();

    public ModeloDB() {
           }

    public static void addExamen(examen p){
        examen=p;
    }
}
