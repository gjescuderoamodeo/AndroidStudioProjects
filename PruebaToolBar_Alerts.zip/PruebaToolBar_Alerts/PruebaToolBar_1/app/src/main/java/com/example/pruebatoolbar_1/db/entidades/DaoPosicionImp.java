package com.example.pruebatoolbar_1.db.entidades;

import java.util.ArrayList;

public class DaoPosicionImp implements IDaoPosicion{


    @Override
    public void addPosicion(Posicion p) {

        ModeloDB.addPosicion(p);
    }

    @Override
    public ArrayList<Posicion> verPosiciones() {
        return ModeloDB.getPosiciones();
    }
}
