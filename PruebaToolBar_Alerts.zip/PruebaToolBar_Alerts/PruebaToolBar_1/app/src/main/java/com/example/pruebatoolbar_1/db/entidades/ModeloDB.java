package com.example.pruebatoolbar_1.db.entidades;

import java.util.ArrayList;

public class ModeloDB {

    public static  ArrayList<Posicion> posiciones=new ArrayList<>();

    public ModeloDB() {
           }

    public static void addPosicion(Posicion p){
        posiciones.add(p);
    }

    public static ArrayList<Posicion> getPosiciones() {
        return posiciones;
    }
}
