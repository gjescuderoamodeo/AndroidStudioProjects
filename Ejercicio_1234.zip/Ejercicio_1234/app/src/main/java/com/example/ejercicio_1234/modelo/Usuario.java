package com.example.ejercicio_1234.modelo;

public class Usuario {
}
