package com.example.pruebatoolbar_1.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.pruebatoolbar_1.R;

public class FormularioAddProfesor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_add_posicion);
    }
}