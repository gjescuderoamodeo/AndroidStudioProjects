package com.example.testmvvm.constantes;

public class Constantes {
    public static final String NOMBRE_DB="CoordenadaDB";
    public static final String NOMBRE_DB2="ItinerarioDB";
    public static final String NOMBRE_TABLA_POSICION="Lugar";
    public static final String NOMBRE_TABLA_RUTA="Ruta";
}
