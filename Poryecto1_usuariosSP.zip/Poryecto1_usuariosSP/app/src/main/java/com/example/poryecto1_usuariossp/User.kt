package com.example.poryecto1_usuariossp

data class User (
    val id:Long,
    var name:String,
    var url:String) {}